# todo_app

A todo app demonstrating the use of basics flutter widgets and the 
state management with provider package

Functions

- add new task
- update an existing task
- delete task
- search