
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/todo_manager.dart';
import '../models/todo.dart';

class DoneTodoScreen extends StatelessWidget {
  const DoneTodoScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tâches achevées'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Consumer<TodoManager>(
          builder: (context,TodoManager data,child){
            return ListView.builder(
              itemCount: data.doneTodos.length,
              itemBuilder: (context,index){
                Todo todo = data.doneTodos[index];
                return ListTile(
                  title: Text(todo.desc),
                  trailing: IconButton(
                    icon: Icon(Icons.undo_rounded),
                    onPressed: (){
                      Provider.of<TodoManager>(context, listen: false).toggle(todo);
                      ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Effectuée avec succès'),
                            duration: Duration(seconds: 2),)
                      );
                    },
                  ),
                );
              },
            );},
        ),
      ),
    );
  }
}
