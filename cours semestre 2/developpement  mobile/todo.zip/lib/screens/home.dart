import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:todo_app/data/todo_manager.dart';
import 'package:todo_app/screens/done_todo.dart';
import 'package:todo_app/screens/new_todo.dart';

import '../models/todo.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  @override
  Widget build(BuildContext context) {

    TodoManager _todoManager = Provider.of<TodoManager>(context, listen: false);

    return Scaffold(
        appBar: AppBar(
          title: Text(widget.title),
          actions: [
            IconButton(
                icon: Icon(Icons.done),
                onPressed: (){
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => DoneTodoScreen()));
                }),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Consumer<TodoManager>(
            builder: (context,TodoManager data,child){
              return ListView.builder(
                itemCount: data.allTodos.length,
                itemBuilder: (context,index){
                  return TodoTile(todo: _todoManager.allTodos[index]);
                },
              );},
          ),
        ),
      //floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.push(context,
            MaterialPageRoute(builder: (context) => NewTodoScreen()));
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class TodoTile extends StatefulWidget {
  final Todo todo;
  const TodoTile({Key? key, required this.todo}) : super(key: key);

  @override
  State<TodoTile> createState() => _TodoTileState();
}

class _TodoTileState extends State<TodoTile> {
  @override
  Widget build(BuildContext context) {
    return ListTile(
        leading: Checkbox(
            value: widget.todo.done,
            onChanged: (bool? value) {
              Provider.of<TodoManager>(context, listen: false).toggle(widget.todo);
              ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Statut changé avec succès'),
                    duration: Duration(seconds: 2),)
              );
            },
        ),
        trailing: IconButton(
          icon: Icon(Icons.delete_forever),
          onPressed: (){
            Provider.of<TodoManager>(context, listen: false).delete(widget.todo);
            ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Suppression effectuée avec succès'),
                  duration: Duration(seconds: 2),)
            );
          }
        ),
        title: Text(widget.todo.desc)
    );
  }
}

