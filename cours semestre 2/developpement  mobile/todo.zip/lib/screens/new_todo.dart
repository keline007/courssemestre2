import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/todo_manager.dart';
import '../models/todo.dart';

class NewTodoScreen extends StatefulWidget {
  const NewTodoScreen({Key? key}) : super(key: key);

  @override
  State<NewTodoScreen> createState() => _NewTodoScreenState();
}

class _NewTodoScreenState extends State<NewTodoScreen> {

  TextEditingController _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ajouter un nouveau Todo'),
      ),
      body: Column(
        children: [
          SizedBox(height: 25,),
          TextField(
            controller: _controller,
          ),
          ElevatedButton(
              child: Text('Ajouter'),
              onPressed: (){
                if(_controller.text == ''){
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Svp bien vouloir remplir tous les champs !'),
                    duration: Duration(seconds: 2),)
                  );
                }else{
                  Provider.of<TodoManager>(context, listen: false).addNew(_controller.text);
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Nouvelle tâche enregistrée avec succès'),
                        duration: Duration(seconds: 2),)
                  );
                }
          })
        ],
      ),
    );
  }
}
