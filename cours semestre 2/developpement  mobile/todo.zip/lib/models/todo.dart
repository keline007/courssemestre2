
class Todo {
  int id;
  String desc;
  bool done;

  Todo(this.id, this.desc, this.done);

  @override
  int get hashCode => id;

  @override
  bool operator==(Object other) => other is Todo && other.id == id;
}