
import 'package:flutter/material.dart';

import '../models/todo.dart';

class TodoManager extends ChangeNotifier{

  static int Count = 5;

  static List<Todo> _todos = [
    Todo(1, 'Apprendre la gestion des évènements avec flutter', false),
    Todo(2, 'Faire les courses au super marché le dimanche à ... heures',  false),
    Todo(3, 'Préparer voyage pour ...', true),
    Todo(4, 'Se rendre au stade pour le match Cameroun vs Cameroun', false),
    Todo(5, 'Apprendre la gestion des évènements avec flutter', false),
  ];


  List<Todo> get allTodos => _todos;
  List<Todo> get doneTodos => _todos.where((todo) => todo.done).toList();

  void addNew(String desc){
    Todo todo = Todo(Count + 1, desc, false);
    _todos.add(todo);
    Count++;
    notifyListeners();
  }

  void toggle(Todo todo){
     int index = _todos.indexOf(todo);
     _todos[index].done = !todo.done;
     notifyListeners();
  }

  void delete(Todo todo){
    _todos.remove(todo);
    notifyListeners();
  }
}